# Autojump Puppet Module for Boxen

## Usage

```puppet
include autojump
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`

