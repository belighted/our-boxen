require 'spec_helper'

describe 'autojump' do
  it { should contain_package('autojump') }
end
