# QT Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-qt.png?branch=master)](https://travis-ci.org/boxen/puppet-qt)

## Usage

```puppet
include qt
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
* `xquartz`
