# Automake Puppet Module for Boxen

Installs automake.

[![Build Status](https://travis-ci.org/tommetge/puppet-automake.png?branch=master)](https://travis-ci.org/tommetge/puppet-automake)

## Usage

```puppet
include automake
```

## Required Puppet Modules

* `boxen`
